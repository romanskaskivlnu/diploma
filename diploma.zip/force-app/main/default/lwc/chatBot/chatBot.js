import { LightningElement, track } from 'lwc';
import getOpenAIResponse from '@salesforce/apex/OpenAiConnect.getOpenAIResponse';
import { updateRecord } from 'lightning/uiRecordApi';
import{ refreshApex } from '@salesforce/apex';

export default class ChatBot extends LightningElement {
    @track userInput = '';
    @track responses = [];
    @track tableData = [];
    @track columns = [];
    @track showTable = false;
    draftValues = [];

    conversationId = 'TESTingt1';

    connectedCallback() {
        // this.conversationId = this.generateConversationId();
    }

    generateConversationId() {
        const timestamp = new Date().getTime();
        const randomNumber = Math.floor(Math.random() * 1000000);
        return `${timestamp}-${randomNumber}`;
    }

    handleInputChange(event) {
        this.userInput = event.target.value;
    }

    handleKeyDown(event) {
        if (event.key === 'Enter') {
            this.handleSend();
        }
    }

    handleSend() {
        const prompt = this.userInput;
        if (prompt) {
            getOpenAIResponse({ conversationId: this.conversationId, prompt })
                .then(response => {
                    this.responses.push({ id: this.responses.length, role: 'user', message: prompt });
                    console.log('this.responses =>\n' + JSON.stringify(this.responses));
                    const responseData = JSON.parse(JSON.stringify(response));
                    if (Array.isArray(responseData) && responseData.length > 0) {
                        const tableColumns = this.extractTableColumns(responseData);
                        this.tableData = responseData;
                        this.columns = tableColumns;
                        this.showTable = true;
                    } else {
                        this.responses.push({ id: this.responses.length, role: 'assistant', isTable: false, message: response });
                        this.showTable = false;
                    }

                    this.userInput = '';
                })
                .catch(error => {
                    console.error(JSON.parse(JSON.stringify(error)));
                });
        }
    }

    extractTableColumns(data) {
        const columns = [];
        for (const key in data[0]) {
            if (key !== 'attributes') {
                columns.push({ label: key, fieldName: key, editable: key !== 'Id' });
            }
        }
        return columns;
    }

    handleCellChange(event) {
        this.draftValues = event.detail.draftValues;
    }

    handleSave(event) {
        console.log('this.draftValues');
        console.log(JSON.stringify(this.draftValues));
        const recordInputs = this.draftValues.slice().map(draft => {
            const fields = { ...draft };
            return { fields };
        });

        const promises = recordInputs.map(recordInput => updateRecord(recordInput));

        Promise.all(promises)
            .then(() => {
                // this.draftValues = [];
                // Refresh the table data to show the updated data
                return refreshApex(this.tableData);
            })
            .catch(error => {
                console.error(JSON.parse(JSON.stringify(error)));
            });
    }
}
